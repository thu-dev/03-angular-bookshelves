import { Component } from '@angular/core';
import firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  
 constructor() {

  const firebaseConfig = {
    apiKey: "AIzaSyBC5jTBDI0Des0IYqOb71vRIcrRQskYqHg",
    authDomain: "bookshelves-6ae50.firebaseapp.com",
    projectId: "bookshelves-6ae50",
    storageBucket: "bookshelves-6ae50.appspot.com",
    messagingSenderId: "39385174414",
    appId: "1:39385174414:web:9948f96f2b0dda882ed4df"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
 }
}
