import { Injectable } from '@angular/core';
import { rejects } from 'assert';
import firebase from 'firebase';
import { resolve } from 'path';
import { error } from 'protractor';

@Injectable(
//   {
//   providedIn: 'root'
// }
)
export class AuthService {

  constructor() { }

  // method 1 : new user
  createNewUser(email: string, password: string) {
    return new Promise(
      (resolve, reject) => {
        firebase.auth().createUserWithEmailAndPassword(email, password).then(
          () => {
            resolve('');
          },
          (error) => {
            reject(error);
          }

        )
      }
    )
  }

  // method 2 : connection
  signInUser(email: string, password: string) {
    return new Promise(
      (resolve, reject) => {
        firebase.auth().signInWithEmailAndPassword(email, password).then(
          () => {
            resolve('');
          },
          (error) => {
            reject(error);
          }
        )
      }
    )
  }

  // method 3 : sign out
  signOutUser() {
    firebase.auth().signOut();
  }

}

